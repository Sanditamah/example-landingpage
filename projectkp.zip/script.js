function ubahMode(){
  const ubah = document.body;
  ubah.classList.toggle("dark");
}